from .crypto_trading import main

if __name__ == '__main__':
    main()
